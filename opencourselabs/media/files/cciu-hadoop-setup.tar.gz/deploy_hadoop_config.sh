#!/bin/sh
# Usage: ./deploy_hadoop_conf.sh KEYFILE MASTER_IP

# NOTE: This script regards the current machine as the master.

SSH_KEY=$1
MASTER=$2
HADOOP_HOME=/etc/hadoop
SCP="scp -q -i $SSH_KEY"
CONF_DIR=conf/$MASTER

# If you want to add new configuration files, please add them to
# the below copy commands.

echo "Deploying Hadoop configuration files:"
echo "  applying to the master..."
cp $CONF_DIR/core-site.xml $HADOOP_HOME/conf
cp $CONF_DIR/mapred-site.xml $HADOOP_HOME/conf
cp $CONF_DIR/hdfs-site.xml $HADOOP_HOME/conf
cp $CONF_DIR/hadoop-env.sh $HADOOP_HOME/conf

echo "  applying to the slaves..."
for SLAVE in `cat $CONF_DIR/slaves`; do
	echo "    copying to $SLAVE..."
	$SCP $CONF_DIR/core-site.xml root@$SLAVE:$HADOOP_HOME/conf
	$SCP $CONF_DIR/mapred-site.xml root@$SLAVE:$HADOOP_HOME/conf
	$SCP $CONF_DIR/hdfs-site.xml root@$SLAVE:$HADOOP_HOME/conf
	$SCP $CONF_DIR/hadoop-env.sh root@$SLAVE:$HADOOP_HOME/conf
done

echo "Ready to run Hadoop."
echo "If this is the first time to start the cluster, run the following commands:"
echo "  sudo -u hadoop hadoop namenode -format"
echo "  sudo -u hadoop /usr/lib/hadoop/bin/start-all.sh"
