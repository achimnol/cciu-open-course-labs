#!/bin/sh
# Usage: ./install_hadoop.sh KEYFILE MASTER_IP SLAVE1_IP SLAVE2_IP ...

#############################################################################
## 인자 받기
#############################################################################
SSH_KEY=$1
MASTER=$2
while test -n "$3"; do
	SLAVE=$3
	SLAVES="$SLAVES $SLAVE"
	shift
done

HADOOP_HOME=/etc/hadoop

echo "This script will setup a Hadoop cluster with:"
echo "  MASTER=$MASTER"
echo "  SLAVES=$SLAVES"
echo -n "Are you sure? (y/n) : "
read YN

if test "$YN" != "y"; then
	exit 1;
fi

HOSTS="$MASTER $SLAVES"
CONF_DIR=conf/$MASTER

SSH_ROOT="ssh -i $SSH_KEY -l root"
SSH_HADOOP="ssh -i $SSH_KEY -l hadoop"

#############################################################################
## 배포해야 할 설정 파일 생성
#############################################################################
echo "Creating configuration files:";

#
echo "  clean up..."
rm -Rf $CONF_DIR
mkdir -p $CONF_DIR

#
echo "  generating /etc/hosts..."
cp conf/template/hosts $CONF_DIR/hosts
echo $MASTER host0 >> $CONF_DIR/hosts
i=1
for SLAVE in $SLAVES; do
	echo $SLAVE host$i >> $CONF_DIR/hosts
	echo $SLAVE >> $CONF_DIR/slaves
	i=`expr $i + 1`
done

#############################################################################
## 호스트 별 설치
#############################################################################
i=0
for HOST in $HOSTS; do
	HOSTNAME="host$i"

	echo "Setting up $HOST:"
	echo "  copying /etc/hosts..."
	scp -q -i $SSH_KEY $CONF_DIR/hosts root@$HOST:/etc/hosts

	echo "  setting hostname..."
	$SSH_ROOT $HOST hostname $HOSTNAME

	echo "  enabling ssh with hadoop user..."
	$SSH_ROOT $HOST mkdir -p /home/hadoop/.ssh
	$SSH_ROOT $HOST cp /root/.ssh/authorized_keys /home/hadoop/.ssh
	$SSH_ROOT $HOST chown -R hadoop:hadoop /home/hadoop
	$SSH_ROOT $HOST usermod --home /home/hadoop --shell /bin/bash hadoop

	echo "  generating hadoop user key pairs..."
	$SSH_HADOOP $HOST "rm -f /home/hadoop/.ssh/id_dsa*"
	$SSH_HADOOP $HOST "ssh-keygen -q -t dsa -P '' -f /home/hadoop/.ssh/id_dsa"
	$SSH_HADOOP $HOST "cat /home/hadoop/.ssh/id_dsa.pub >> /home/hadoop/.ssh/authorized_keys"

	## Master
	if test "$i" = "0" ; then
		echo "  copying master pub key to local..."
		scp -q -i $SSH_KEY root@$MASTER:/home/hadoop/.ssh/id_dsa.pub $CONF_DIR/id_dsa.pub.master
		scp -q -i $SSH_KEY $CONF_DIR/slaves root@$MASTER:$HADOOP_HOME/conf
		
		echo 'StrictHostKeyChecking=no' > /root/.ssh/config
		echo 'StrictHostKeyChecking=no' > /home/hadoop/.ssh/config
	fi

	## Slave
	if test "$i" != "0" ; then
		echo "  enabling ssh from the master.."
		scp -q -i $SSH_KEY $CONF_DIR/id_dsa.pub.master hadoop@$HOST:/home/hadoop/.ssh/id_dsa.pub.master
		$SSH_HADOOP $HOST "cat /home/hadoop/.ssh/id_dsa.pub.master >> /home/hadoop/.ssh/authorized_keys"
	fi

	echo "  making /mnt/hadoop for HDFS..."
	$SSH_ROOT $HOST mkdir -p /mnt/hadoop
	$SSH_ROOT $HOST chown -R hadoop:hadoop /mnt/hadoop

	i=`expr $i + 1`
done

echo "Generating default Hadoop configuration..."
num_nodes=`expr $i - 1`
echo "  number of data nodes: $num_nodes"
num_replication=3
if [ $num_nodes -le 5 ] ; then
	num_replication=2
fi
if [ $num_nodes -le 3 ] ; then
	num_replication=1
fi
echo "  suggested HDFS replications: $num_replication"

sed -e s/MASTER/$MASTER/g conf/template/core-site.xml > $CONF_DIR/core-site.xml
sed -e s/MASTER/$MASTER/g conf/template/mapred-site.xml > $CONF_DIR/mapred-site.xml
sed -e s/MASTER/$MASTER/g -e s/REPLICATION/$num_replication/g conf/template/hdfs-site.xml > $CONF_DIR/hdfs-site.xml
cp conf/template/hadoop-env.sh $CONF_DIR/hadoop-env.sh

echo "Ready to confingure Hadoop."
echo "Edit $CONF_DIR/*-site.xml as you wish,"
echo "and run ./deploy_hadoop_conf.sh KEYFILE MASTER"
